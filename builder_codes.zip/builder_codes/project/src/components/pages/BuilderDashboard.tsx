import React from 'react';
import { Building2, Users, Star, Briefcase, ChevronRight } from 'lucide-react';

export function BuilderDashboard() {
  // Mock data - replace with actual API data
  const stats = [
    { label: 'Total Projects', value: '45', icon: Building2 },
    { label: 'Active Clients', value: '12', icon: Users },
    { label: 'Average Rating', value: '4.8', icon: Star },
    { label: 'Years Experience', value: '15', icon: Briefcase },
  ];

  const recentProjects = [
    {
      id: 1,
      title: 'Modern Villa Construction',
      client: 'John Smith',
      status: 'In Progress',
      completion: '75%',
    },
    {
      id: 2,
      title: 'Office Renovation',
      client: 'Tech Corp',
      status: 'Completed',
      completion: '100%',
    },
    {
      id: 3,
      title: 'Apartment Complex',
      client: 'Real Estate Ltd',
      status: 'Planning',
      completion: '10%',
    },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Builder Dashboard</h1>
        <p className="mt-2 text-gray-600">Welcome back, Modern Builders Co.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                <p className="mt-2 text-3xl font-semibold text-gray-900">{stat.value}</p>
              </div>
              <stat.icon className="w-12 h-12 text-blue-600" />
            </div>
          </div>
        ))}
      </div>

      {/* Recent Projects */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Recent Projects</h2>
        </div>
        <div className="divide-y divide-gray-200">
          {recentProjects.map((project) => (
            <div key={project.id} className="p-6 hover:bg-gray-50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{project.title}</h3>
                  <p className="mt-1 text-sm text-gray-600">Client: {project.client}</p>
                </div>
                <div className="flex items-center">
                  <div className="mr-4 text-right">
                    <p className="text-sm font-medium text-gray-900">{project.status}</p>
                    <p className="text-sm text-gray-600">{project.completion}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}