import { Builder } from '../types';

// Convert the CSV data to Builder objects
export const BUILDERS: Builder[] = [
  {
    builder_id: 1,
    name: "R K CONSTRUCTIONS",
    gst_number: "33FAXPS3993A1Z4",
    address: "No.2/222, 1st Cross Street, Raghava Nagar, Madipakkam, Chennai, Kancheepuram, Tamil Nadu, 600091",
    contact_info: {
      phone: null,
      email: "contact@rkconstructions.com"
    },
    is_gst_verified: true,
    experience: "8 years",
    category: "established",
    projects_completed: 120,
    registered_at: "2020-01-01T00:00:00Z",
    builder_image: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=800",
    rating: 4.5,
    total_reviews: 85,
    verified: true,
    specializations: ["Residential", "Commercial"]
  },
  {
    builder_id: 2,
    name: "Shrii Dharshini Builders",
    gst_number: "33AMWPC7084L1ZG",
    address: "No.4/24, 3RD STREET / JEEVAN NAGAR, ADAMBAKKAM, Chennai, Tamil Nadu, 600088",
    contact_info: {
      phone: null,
      email: "info@dharshinibuilders.com"
    },
    is_gst_verified: true,
    experience: "6 years",
    category: "established",
    projects_completed: 75,
    registered_at: "2021-03-15T00:00:00Z",
    builder_image: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=800",
    rating: 4.7,
    total_reviews: 62,
    verified: true,
    specializations: ["Residential", "Interior"]
  },
  {
    builder_id: 3,
    name: "RAMCONS",
    gst_number: "33AAIPR6430P1Z8",
    address: "2nd Floor, No. 1/2, Ramcons Fortuna Towers, Kodambakkam high road, Nungambakkam, Chennai, Chennai, Tamil Nadu, 600034",
    contact_info: {
      phone: null,
      email: "info@ramcons.com"
    },
    is_gst_verified: true,
    experience: "12 years",
    category: "established",
    projects_completed: 200,
    registered_at: "2019-05-20T00:00:00Z",
    builder_image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=800",
    rating: 4.8,
    total_reviews: 150,
    verified: true,
    specializations: ["Commercial", "Residential", "High-rise"]
  },
  {
    builder_id: 4,
    name: "Kamalam Builders",
    gst_number: "33AAFPV4954M1Z4",
    address: "Mezzanine Floor, No.189 / office No.14, Aarti chamber building, Anna salai, Anna salai, Chennai, Tamil Nadu, 600006",
    contact_info: {
      phone: null,
      email: "contact@kamalambuilders.com"
    },
    is_gst_verified: true,
    experience: "5 years",
    category: "established",
    projects_completed: 45,
    registered_at: "2022-01-10T00:00:00Z",
    builder_image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800",
    rating: 4.6,
    total_reviews: 38,
    verified: true,
    specializations: ["Residential"]
  },
  {
    builder_id: 5,
    name: "ATULIT",
    gst_number: "33AEDPG8496H1ZB",
    address: "No.22/12 Flat No.1B, Asvini Abinav Apartment, JAI NAGAR 16TH STREET, Arumbakkam, Chennai, Tamil Nadu, 600106",
    contact_info: {
      phone: "9940341775",
      email: "contact@atulit.com"
    },
    is_gst_verified: true,
    experience: "3 years",
    category: "beginner",
    projects_completed: 25,
    registered_at: "2023-02-15T00:00:00Z",
    builder_image: "https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&w=800",
    rating: 4.4,
    total_reviews: 18,
    verified: true,
    specializations: ["Residential", "Interior"]
  }
];