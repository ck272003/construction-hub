// User related types
export interface User {
  user_id: number;
  name: string;
  email: string;
  phone_number: string;
  user_type: 'client' | 'admin';
  registered_at: string;
}

export interface Builder {
  builder_id: number;
  name: string;
  address: string;
  license_no: string;
  gst_number: string;
  experience: string;
  contact_info: {
    phone: string;
    email: string;
  };
  builder_image: string;
  registered_at: string;
  // Computed fields from relationships
  rating?: number;
  total_reviews?: number;
  verified?: boolean;
}

export interface ClientRequest {
  request_id: number;
  client_id: number;
  builder_id: number;
  request_details: string;
  status: 'pending' | 'accepted' | 'rejected' | 'done';
  created_at: string;
}

export interface Message {
  message_id: number;
  sender_id: number;
  receiver_id: number;
  content: string;
  sent_at: string;
}

export interface Review {
  review_id: number;
  client_id: number;
  builder_id: number;
  rating: number;
  review_text: string;
  created_at: string;
}

export interface SearchFilters {
  location: string;
  service: string;
  rating: number;
  experience: number;
}