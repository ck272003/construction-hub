import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Building } from 'lucide-react';
import { Builder, SearchFilters, User } from './types';
import { BuilderCard } from './components/BuilderCard';
import { SearchFiltersPanel } from './components/SearchFilters';
import { LoginModal } from './components/LoginModal';
import { BuilderDetails } from './components/BuilderDetails';

// Mock data - In a real app, this would come from the database
const MOCK_BUILDERS: Builder[] = [
  {
    builder_id: 1,
    name: 'Modern Builders Co.',
    address: 'New York, NY',
    license_no: 'LIC123456',
    gst_number: 'GST98765432',
    experience: '15 years',
    contact_info: {
      phone: '(555) 123-4567',
      email: 'contact@modernbuilders.com'
    },
    builder_image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=800',
    registered_at: '2020-01-01T00:00:00Z',
    rating: 4.8,
    total_reviews: 156,
    verified: true
  },
  {
    builder_id: 2,
    name: 'Green Construction Ltd.',
    address: 'Los Angeles, CA',
    license_no: 'LIC789012',
    gst_number: 'GST45678901',
    experience: '10 years',
    contact_info: {
      phone: '(555) 234-5678',
      email: 'info@greenconstruction.com'
    },
    builder_image: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=800',
    registered_at: '2021-03-15T00:00:00Z',
    rating: 4.6,
    total_reviews: 89,
    verified: true
  },
  {
    builder_id: 3,
    name: 'Urban Developers Inc.',
    address: 'Chicago, IL',
    license_no: 'LIC345678',
    gst_number: 'GST12345678',
    experience: '8 years',
    contact_info: {
      phone: '(555) 345-6789',
      email: 'contact@urbandevelopers.com'
    },
    builder_image: 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=800',
    registered_at: '2022-06-30T00:00:00Z',
    rating: 4.5,
    total_reviews: 45,
    verified: false
  }
];

function HomePage() {
  const [filters, setFilters] = useState<SearchFilters>({
    location: '',
    service: '',
    rating: 0,
    experience: 0,
  });

  const filteredBuilders = MOCK_BUILDERS.filter(builder => {
    if (filters.location && !builder.address.toLowerCase().includes(filters.location.toLowerCase())) {
      return false;
    }
    if (filters.service && !builder.name.toLowerCase().includes(filters.service.toLowerCase())) {
      return false;
    }
    if (filters.rating > 0 && (!builder.rating || builder.rating < filters.rating)) {
      return false;
    }
    if (filters.experience > 0) {
      const yearsExp = parseInt(builder.experience);
      if (isNaN(yearsExp) || yearsExp < filters.experience) {
        return false;
      }
    }
    return true;
  });

  return (
    <>
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold text-gray-900 mb-4">
          Find Trusted Construction Professionals
        </h2>
        <p className="text-xl text-gray-600">
          Connect with verified builders and get your project started today
        </p>
      </div>

      {/* Search Filters */}
      <div className="mb-8">
        <SearchFiltersPanel 
          filters={filters}
          onFilterChange={setFilters}
        />
      </div>

      {/* Builder Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredBuilders.map((builder) => (
          <BuilderCard
            key={builder.builder_id}
            builder={builder}
            isLoggedIn={true}
            onConnect={() => {}}
          />
        ))}
      </div>

      {filteredBuilders.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-600">No builders found matching your criteria.</p>
        </div>
      )}
    </>
  );
}

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building className="text-blue-600" size={32} />
              <h1 className="text-2xl font-bold text-gray-900">BuildConnect</h1>
            </div>
            <button 
              onClick={() => user ? setUser(null) : setIsLoginModalOpen(true)}
              className="px-4 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700"
            >
              {user ? 'Logout' : 'Login / Sign Up'}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/builder/:id" element={<BuilderDetails builders={MOCK_BUILDERS} />} />
        </Routes>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">About BuildConnect</h3>
              <p className="text-gray-400">
                Connecting quality builders with clients for successful construction projects.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Find Builders</li>
                <li>How it Works</li>
                <li>Become a Builder</li>
                <li>Support</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Email: support@buildconnect.com</li>
                <li>Phone: (555) 123-4567</li>
              </ul>
            </div>
          </div>
        </div>
      </footer>

      {/* Login Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLogin={setUser}
      />
    </div>
  );
}

export default App;